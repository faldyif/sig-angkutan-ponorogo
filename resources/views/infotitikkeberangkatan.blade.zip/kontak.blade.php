@extends('layouts.visitor')

@section('content')    
<div class="container">

    <div class="row">
        <div class="box">
            <div class="col-lg-12">
                <hr>
                <h2 class="intro-text text-center">Contact
                    <strong>business casual</strong>
                </h2>
                <hr>
            </div>
            <div class="col-md-6 peneliti">
                <p>Nama:
                    <strong>Septian Johan Firmansyah</strong>
                </p>
                <p>Program Studi:
                    <strong>Penginderaan Jauh dan SIG</strong>
                </p>
                <p>Email:
                    <strong><a href="mailto:johan.irwan19@gmail.com">johan.irwan19@gmail.com</a></strong>
                </p>
                <img src="img/septian.jpg" width="100px">
            </div>
            <div class="col-md-6 peneliti">
                <p>Nama:
                    <strong>Faldy Ikhwan Fadila</strong>
                </p>
                <p>Program Studi:
                    <strong>Ilmu Komputer dan SI</strong>
                </p>
                <p>Email:
                    <strong><a href="mailto:faldy.if@live.com">faldy.if@live.com</a></strong>
                </p>
                <img src="img/faldy.jpg" width="100px">
            </div>
            <div class="clearfix"></div>
        </div>
    </div>

    <div class="row">
        <div class="box">
            <div class="col-lg-12">
                <hr>
                <h2 class="intro-text text-center">
                    <strong>Form</strong> kontak
                </h2>
                <hr>
                <p>Tinggalkan kritik/saran untuk pengembangan website ini.</p>
                <form role="form">
                    <div class="row">
                        <div class="form-group col-lg-4">
                            <label>Name</label>
                            <input type="text" class="form-control">
                        </div>
                        <div class="form-group col-lg-4">
                            <label>Email Address</label>
                            <input type="email" class="form-control">
                        </div>
                        <div class="form-group col-lg-4">
                            <label>Phone Number</label>
                            <input type="tel" class="form-control">
                        </div>
                        <div class="clearfix"></div>
                        <div class="form-group col-lg-12">
                            <label>Message</label>
                            <textarea class="form-control" rows="6"></textarea>
                        </div>
                        <div class="form-group col-lg-12">
                            <input type="hidden" name="save" value="contact">
                            <button type="submit" class="btn btn-default">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
@endsection
